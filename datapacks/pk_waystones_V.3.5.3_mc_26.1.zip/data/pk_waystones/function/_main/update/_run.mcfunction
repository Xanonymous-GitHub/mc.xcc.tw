#> pk_waystones:_main/update/start
# Update the current data pack if needed

# V.3.1.0
execute unless score $pk.waystones.version pk.value matches 1.. run function pk_waystones:_main/update/versions/3_1_0
# V.3.3.0
execute unless score $pk.waystones.version pk.value matches 9.. run function pk_waystones:_main/update/versions/3_3_0
# V.3.3.2
execute unless score $pk.waystones.version pk.value matches 30302.. run function pk_waystones:_main/update/versions/3_3_2/start
# V.3.4.0
execute unless score $pk.waystones.version pk.value matches 30400.. run function pk_waystones:_main/update/versions/3_4_0
# V.3.4.6
execute unless score $pk.waystones.version pk.value matches 30406.. run function pk_waystones:_main/update/versions/3_4_6/1
# V.3.4.7
execute unless score $pk.waystones.version pk.value matches 30407.. run function pk_waystones:_main/update/versions/3_4_7
# V.3.5.3
execute unless score $pk.waystones.version pk.value matches 30503.. run function pk_waystones:_main/update/versions/3_5_3

# Set the data pack current version score
scoreboard players set $pk.waystones.version pk.value 30503
data modify storage pk:common installed_datapacks[{id:"waystones"}].version set value "3.5.3"