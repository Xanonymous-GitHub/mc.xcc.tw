# Gorify
A Minecraft Datapack to add blood, bleedings, suffocations and broken bones. It's pure cosmetic.

# Requires 
- Minecraft 1.20.5+

# Use
1. Download the package
2. Copy/paste the entire "Gorify/" folder in your "saves/your-map/datapacks/" folder.
3. Launch the game/server and play your map as you always do.

# Author
- Name : FunkyToc
- Website : https://funkytoc.fr

# License
This work is licensed under the Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License: http://creativecommons.org/licenses/by-nc-nd/4.0/

# Thanks 
...
